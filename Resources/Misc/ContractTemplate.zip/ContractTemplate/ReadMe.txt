Before importing this zip file, please check the CSV dates so that they are consistent with the current period.

- All lines: EndDate__ must come after the current date.
- Coffee service (amend): EffectiveDate__ must come after the existing contract start date (e.g. after 2027-01-01 if you activated your demo data in 2027) and before its end date.
- Standard Furniture Supply Agreement (termination): EffectiveDate__ must come after the existing contract start date (e.g. after 2027-01-01 if you activated your demo data in 2027).

CSV last update: 31 December 2025 (PAC/MCH)